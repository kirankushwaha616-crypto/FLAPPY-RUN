import { describe, expect, it } from "vitest";
import { COIN_PICKUP_REWARD, milestoneBonus, purchase } from "@/game/rules";

describe("coin rewards", () => {
  it("gives 1 coin per coin picked up", () => {
    expect(COIN_PICKUP_REWARD).toBe(1);
  });
  it("gives a 5 coin bonus every 10 pipes", () => {
    expect(milestoneBonus(10)).toBe(5);
    expect(milestoneBonus(20)).toBe(5);
    expect(milestoneBonus(9)).toBe(0);
    expect(milestoneBonus(0)).toBe(0);
  });
});

describe("purchases", () => {
  it("blocks buying the same item twice", () => {
    const r = purchase({ coins: 100, owned: ["a"] }, "a", 10);
    expect(r).toEqual({ ok: false, reason: "already-owned" });
  });
  it("blocks buying without enough coins", () => {
    const r = purchase({ coins: 5, owned: [] }, "a", 10);
    expect(r).toEqual({ ok: false, reason: "not-enough-coins" });
  });
  it("deducts the price and records ownership", () => {
    const r = purchase({ coins: 25, owned: [] }, "a", 10);
    expect(r).toEqual({ ok: true, wallet: { coins: 15, owned: ["a"] } });
  });
});
