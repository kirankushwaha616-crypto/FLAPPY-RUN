import { createFileRoute } from "@tanstack/react-router";
import { FlappyFaceGame } from "@/components/game/FlappyFaceGame";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Flappy Face — Tap to fly through pipes" },
      {
        name: "description",
        content: "Fly your favourite face through pipes across Nature, Himalaya and Dense Jungle worlds. Collect coins and beat your best.",
      },
      { property: "og:title", content: "Flappy Face — Tap to fly through pipes" },
      {
        property: "og:description",
        content: "Fly your favourite face through pipes across Nature, Himalaya and Dense Jungle worlds.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FlappyFaceGame,
});
