import faceClassic from "@/assets/faces/face-classic.png.asset.json";
import faceGolden from "@/assets/faces/face-golden-legend.png.asset.json";
import faceAlen from "@/assets/faces/face-alen.png.asset.json";
import faceNinja from "@/assets/faces/face-ninja.png.asset.json";
import faceMonster from "@/assets/faces/face-mini-monster.png.asset.json";
import faceIce from "@/assets/faces/face-ice-spirit.png.asset.json";
import faceSleepy from "@/assets/faces/face-sleepy.png.asset.json";
import faceAngry from "@/assets/faces/face-angry.png.asset.json";
import rahul from "@/assets/faces/rahul-gandhi.png.asset.json";
import putin from "@/assets/faces/putin.png.asset.json";
import modi from "@/assets/faces/narendra-modi.png.asset.json";
import elon from "@/assets/faces/elon-musk.png.asset.json";
import mukesh from "@/assets/faces/mukesh-ambani.png.asset.json";
import mahatma from "@/assets/faces/mahatma-gandhi.png.asset.json";

export type FaceId = string;
export type SceneryId = "nature" | "himalaya" | "jungle";

export interface FaceItem {
  id: FaceId;
  name: string;
  group: "cartoon" | "celebrity";
  image: string;
  /** Coin price. 0 = free. Prices are set by the game owner only. */
  price: number;
}

export interface SceneryItem {
  id: SceneryId;
  name: string;
  tagline: string;
  /** Original background script, served unchanged from /public/game. */
  script: string;
  price: number;
}

// All prices are 0 until the owner approves real prices.
export const FACES: FaceItem[] = [
  { id: "face-classic", name: "Classic", group: "cartoon", image: faceClassic.url, price: 0 },
  { id: "face-golden-legend", name: "Golden Legend", group: "cartoon", image: faceGolden.url, price: 0 },
  { id: "face-alen", name: "Alen", group: "cartoon", image: faceAlen.url, price: 0 },
  { id: "face-ninja", name: "Ninja", group: "cartoon", image: faceNinja.url, price: 0 },
  { id: "face-mini-monster", name: "Mini Monster", group: "cartoon", image: faceMonster.url, price: 0 },
  { id: "face-ice-spirit", name: "Ice Spirit", group: "cartoon", image: faceIce.url, price: 0 },
  { id: "face-sleepy", name: "Sleepy", group: "cartoon", image: faceSleepy.url, price: 0 },
  { id: "face-angry", name: "Angry", group: "cartoon", image: faceAngry.url, price: 0 },
  { id: "rahul-gandhi", name: "Rahul Gandhi", group: "celebrity", image: rahul.url, price: 0 },
  { id: "putin", name: "Putin", group: "celebrity", image: putin.url, price: 0 },
  { id: "narendra-modi", name: "Narendra Modi", group: "celebrity", image: modi.url, price: 0 },
  { id: "elon-musk", name: "Elon Musk", group: "celebrity", image: elon.url, price: 0 },
  { id: "mukesh-ambani", name: "Mukesh Ambani", group: "celebrity", image: mukesh.url, price: 0 },
  { id: "mahatma-gandhi", name: "Mahatma Gandhi", group: "celebrity", image: mahatma.url, price: 0 },
];

export const SCENERIES: SceneryItem[] = [
  {
    id: "nature",
    name: "Nature",
    tagline: "Rolling hills, mountains & clouds",
    script: "/game/parallax-nature-background.js",
    price: 0,
  },
  {
    id: "himalaya",
    name: "Himalaya",
    tagline: "Snow peaks & alpine forests",
    script: "/game/himalaya.js",
    price: 0,
  },
  {
    id: "jungle",
    name: "Dense Jungle",
    tagline: "Giant trees & hanging vines",
    script: "/game/dense-jungle.js",
    price: 0,
  },
];

export const DEFAULT_FACE: FaceId = "face-classic";
export const DEFAULT_SCENERY: SceneryId = "nature";

export const getFace = (id: FaceId) => FACES.find((f) => f.id === id) ?? FACES[0]!;
export const getScenery = (id: SceneryId) => SCENERIES.find((s) => s.id === id) ?? SCENERIES[0]!;
